package machine;

/**
 * Encapsulates the state of a vending machine and the operations that can be performed on it
 */
public class VendingMachine {
	
	public VendingMachine() {
		super();
	}
	
	public boolean isOn() {
		return false;
	}
	
	public void setOn() {
	}
	
	public void setOff() {
	}
}
